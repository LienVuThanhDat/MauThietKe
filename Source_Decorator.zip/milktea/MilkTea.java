package milktea;

public class MilkTea implements Drink {
    @Override
    public String getDescription() {
        return "Milk Tea";
    }

    @Override
    public double cost() {
        return 25000.0;
    }
}
