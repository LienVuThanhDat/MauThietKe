package milktea;

public class ProgramMilkTea {
    public static void main(String[] args) {
        Drink order = new MilkTea();
        order = new Pearl(order);
        order = new Pudding(order);
        order = new GrassJelly(order);

        System.out.println("Your order: " + order.getDescription());
        System.out.println("Total cost: " + order.cost() + " VND");
    }
}
