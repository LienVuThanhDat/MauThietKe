package milktea;

public interface Drink {
    String getDescription();
    double cost();
}
