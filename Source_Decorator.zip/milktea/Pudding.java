package milktea;

public class Pudding extends ToppingDecorator {
    public Pudding(Drink drink) {
        super(drink);
    }

    @Override
    public String getDescription() {
        return targetDrink.getDescription() + " + Pudding";
    }

    @Override
    public double cost() {
        return targetDrink.cost() + 7000.0;
    }
}
