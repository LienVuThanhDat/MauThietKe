package milktea;

public class GrassJelly extends ToppingDecorator {
    public GrassJelly(Drink drink) {
        super(drink);
    }

    @Override
    public String getDescription() {
        return targetDrink.getDescription() + " + Grass Jelly";
    }

    @Override
    public double cost() {
        return targetDrink.cost() + 4000.0;
    }
}
