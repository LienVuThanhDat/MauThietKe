package milktea;

public abstract class ToppingDecorator implements Drink {
    protected Drink targetDrink;

    public ToppingDecorator(Drink drink) {
        this.targetDrink = drink;
    }

    @Override
    public String getDescription() {
        return targetDrink.getDescription();
    }

    @Override
    public double cost() {
        return targetDrink.cost();
    }
}
