package milktea;

public class Pearl extends ToppingDecorator {
    public Pearl(Drink drink) {
        super(drink);
    }

    @Override
    public String getDescription() {
        return targetDrink.getDescription() + " + Pearl";
    }

    @Override
    public double cost() {
        return targetDrink.cost() + 5000.0;
    }
}
