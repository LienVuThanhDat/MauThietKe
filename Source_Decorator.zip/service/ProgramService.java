package service;

public class ProgramService {
    public static void main(String[] args) {
        Service base = new BaseService();
        Service logged = new LogDecorator(base);

        Request req = new Request("Hello Decorator Pattern");
        Response res = logged.handle(req);

        System.out.println("Final result to client: " + res);
    }
}
