package service;

public class BaseService implements Service {
    @Override
    public Response handle(Request req) {
        String result = "Processed: " + req.getPayload();
        return new Response(result, 200);
    }
}
