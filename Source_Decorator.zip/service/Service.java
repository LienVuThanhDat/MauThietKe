package service;

public interface Service {
    Response handle(Request req);
}
