package service;

public class LogDecorator implements Service {
    private Service target;

    public LogDecorator(Service target) {
        this.target = target;
    }

    @Override
    public Response handle(Request req) {
        System.out.println("[LOG] Incoming request: " + req.getPayload());
        Response res = target.handle(req);
        System.out.println("[LOG] Outgoing response: " + res.toString());
        return res;
    }
}
