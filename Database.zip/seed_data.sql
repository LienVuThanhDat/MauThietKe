-- seed_data.sql
INSERT INTO Drinks (Name, Price) VALUES ('Milk Tea', 25000);
INSERT INTO Toppings (Name, Price) VALUES ('Pearl', 5000), ('Pudding', 7000), ('Grass Jelly', 4000);

-- Create a sample order
INSERT INTO Orders DEFAULT VALUES;
DECLARE @OrderID INT = SCOPE_IDENTITY();

INSERT INTO OrderItems (OrderID, DrinkID) VALUES (@OrderID, 1);
DECLARE @ItemID INT = SCOPE_IDENTITY();

INSERT INTO OrderItemToppings (ItemID, ToppingID) VALUES
(@ItemID, 1),
(@ItemID, 2),
(@ItemID, 3);

-- Resulting total = 25000 + 5000 + 7000 + 4000 = 41000
