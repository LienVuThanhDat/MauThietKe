README_DB.txt
-----------------
📘 CẤU TRÚC DATABASE CHO ĐỒ ÁN DECORATOR

1️⃣ Drinks: Lưu thông tin các loại đồ uống cơ bản (ConcreteComponent).
2️⃣ Toppings: Lưu các loại topping bổ sung (ConcreteDecorator).
3️⃣ Orders: Thông tin hóa đơn.
4️⃣ OrderItems: Mỗi đồ uống trong hóa đơn (tham chiếu đến Drinks).
5️⃣ OrderItemToppings: Liên kết giữa Item và Topping (quan hệ N-N).

💡 Mục tiêu: Mô phỏng nguyên lý Decorator trong thực tế — mỗi đồ uống có thể “được trang trí” bằng nhiều topping khác nhau mà không cần thay đổi cấu trúc gốc.

⚙️ Cách sử dụng:
- Chạy file schema.sql để tạo bảng.
- Chạy file seed_data.sql để chèn dữ liệu mẫu.
- Dùng SQL Server, MySQL hoặc SQLite đều tương thích (chỉ cần đổi cú pháp IDENTITY/AutoIncrement).

📈 Kết quả:
Một đơn hàng mẫu: Milk Tea + Pearl + Pudding + Grass Jelly = 41.000 VND
