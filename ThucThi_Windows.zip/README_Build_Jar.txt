HƯỚNG DẪN BUILD FILE DecoratorDemo.jar (Windows)

YÊU CẦU:
1. Đã cài JDK (java, javac chạy được trong CMD)
2. Thư mục Source/ nằm cùng cấp với thư mục ThucThi_Windows/

CÁC BƯỚC:

1. Biên dịch mã nguồn
   cd Source
   javac milktea\*.java service\*.java

   Lệnh này sẽ tạo các file .class trong từng package.

2. Đóng gói .jar
   Quay lại thư mục cha (nơi có Source\ và ThucThi_Windows\)
   jar cfe ThucThi_Windows\DecoratorDemo.jar milktea.ProgramMilkTea -C Source milktea -C Source service

   Giải thích:
   - 'cfe' tạo jar và set Main-Class = milktea.ProgramMilkTea
   - Jar sẽ chứa cả class trong milktea và service
   - Mặc định double-click DecoratorDemo.jar sẽ chạy ProgramMilkTea

3. Chạy demo từ CMD:
   cd ThucThi_Windows
   java -jar DecoratorDemo.jar          <-- chạy MilkTea (main mặc định)
   run-milktea.bat                      <-- tương tự
   run-service.bat                      <-- chạy main service.ProgramService



Sinh viên nộp: 2212351
Môn: Mẫu Thiết Kế (Design Pattern)
Đề tài: Decorator Pattern
